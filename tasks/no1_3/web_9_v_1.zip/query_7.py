from flask import Flask
from temp.Tests_ex.web_9.tasks.no1_1.data import db_session
from temp.Tests_ex.web_9.tasks.no1_1.data.users import User
from temp.Tests_ex.web_9.tasks.no1_1.data.jobs import Jobs

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/mars_explorer.sqlite")
    # app.run()

    session = db_session.create_session()

    for user in session.query(User).filter(User.address == "module_1",
                                           User.age < 21):
        user.address = "module_3"
    session.commit()


if __name__ == '__main__':
    main()
